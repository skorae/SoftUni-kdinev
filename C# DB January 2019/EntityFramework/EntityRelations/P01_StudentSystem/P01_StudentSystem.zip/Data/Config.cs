﻿namespace P01_StudentSystem.Data
{
    public class Config
    {
        public const string ConnectionString = @"Server=DESKTOP-L5A0R6C\SQLEXPRESS;Database=StudentSystem;Integrated Security = True";
    }
}
