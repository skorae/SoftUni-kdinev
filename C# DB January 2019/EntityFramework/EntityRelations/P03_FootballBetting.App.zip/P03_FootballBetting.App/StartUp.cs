﻿namespace P03_FootballBetting.App
{
    using P03_FootballBetting.Data;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            
        }
    }
}
