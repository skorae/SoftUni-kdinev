﻿namespace P03_FootballBetting.Data.Config
{
    public class ConnectionStringConfig
    {
        public const string ConnectionString = @"Server=DESKTOP-L5A0R6C\SQLEXPRESS;Database=FootballBetting;Integrated Security=True;";
    }
}
