﻿namespace CarDealer.Dtos.Export
{
    using System.Xml.Serialization;

    [XmlType("car")]
    public class ExportCarWithPartDto
    {
        public CarWithPartsDto[] CarWithParts { get; set; }
    }
}
