﻿namespace CarDealer.Dtos.Export
{
    using System.Xml.Serialization;

    [XmlType("car")]
    public class CarWithPartsDto
    {
        [XmlAttribute(AttributeName = "make")]
        public ExportCarAttributeDto Car { get; set; }

        [XmlArray("parts")]
        public ExportParAtributeDto[] Parts { get; set; }
    }
}
