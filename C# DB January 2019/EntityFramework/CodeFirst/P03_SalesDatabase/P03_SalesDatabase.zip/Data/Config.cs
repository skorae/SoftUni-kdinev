﻿namespace P03_SalesDatabase.Data
{
   public class Config
    {
        public const string ConnectionString = @"Server=DESKTOP-L5A0R6C\SQLEXPRESS;DataBase=Sales;Integrated Security=True;";
    }
}
