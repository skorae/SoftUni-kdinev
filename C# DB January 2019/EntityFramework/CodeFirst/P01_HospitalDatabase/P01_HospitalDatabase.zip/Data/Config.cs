﻿namespace P01_HospitalDatabase.Data
{
    internal class Config
    {
        public static string ConnectionString = @"DESKTOP-L5A0R6C\SQLEXPRESS;Database:Hospital;Integrated Security=True;";
    }
}