﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => @"Server=DESKTOP-L5A0R6C\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
