﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
            @"Server=DESKTOP-L5A0R6C\SQLEXPRESS;Database=VaporStore;Trusted_Connection=True";
	}
}