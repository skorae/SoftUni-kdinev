namespace FastFood.Data
{
	public static class Configuration
	{
		public static string ConnectionString = @"Server=DESKTOP-L5A0R6C\SQLEXPRESS;Database=FastFood;Trusted_Connection=True";
	}
}