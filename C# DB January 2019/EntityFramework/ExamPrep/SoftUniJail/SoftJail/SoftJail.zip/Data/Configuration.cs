﻿namespace SoftJail.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-L5A0R6C\SQLEXPRESS;Database=SoftJail;Trusted_Connection=True";
    }
}
