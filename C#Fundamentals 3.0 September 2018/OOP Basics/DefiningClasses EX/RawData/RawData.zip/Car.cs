﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RawData
{
    public class Car
    {
        private string model;
        private Engine engine;
        private Cargo carg;
        private List<Tire> tires;

        public Car(string model,Engine engine, Cargo cargo,List<Tire> tires)
        {
            this.Model = model;
            this.Engine = engine;
            this.Cargo = cargo;
            this.Tires = tires;
        }

        public string Model
        {
            get { return this.model; }
            set { this.model = value; }
        }
        public Engine Engine
        {
            get { return engine; }
            set { engine = value; }
        }
        
        public Cargo Cargo
        {
            get { return carg; }
            set { carg = value; }
        }
        
        public List<Tire> Tires
        {
            get { return tires; }
            set { tires = value; }
        }

    }
}
