﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Entity.Characters.Contracts
{
    public enum Faction
    {
        CSharp,
        Java
    }
}
