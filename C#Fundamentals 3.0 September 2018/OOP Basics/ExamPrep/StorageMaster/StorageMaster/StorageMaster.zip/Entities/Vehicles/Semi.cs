﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StorageMaster.Entities.Vehicles
{
    public class Semi : Vehicle
    {
        public Semi() 
            : base(capacity: 10)
        {
        }
    }
}
