﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl.Interface
{
    public interface IPet
    {
        string Name { get; }

        string Birthday { get; }
    }
}
