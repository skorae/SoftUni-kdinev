﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl.Interface
{
    public interface IRebel
    {
        string Name { get; }

        string Age { get; }

        string Group { get; }
    }
}
