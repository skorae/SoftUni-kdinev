﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony.Interface
{
    public interface ICallable
    {
        void Call();
    }
}
