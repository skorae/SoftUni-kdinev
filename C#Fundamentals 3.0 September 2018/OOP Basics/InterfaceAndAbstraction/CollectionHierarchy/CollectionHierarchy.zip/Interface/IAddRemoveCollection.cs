﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace CollectionHierarchy.Interface
{
    public interface IAddRemoveCollection
    {
        void Add(string[] arr);

        void Remove(int n);
    }
}
