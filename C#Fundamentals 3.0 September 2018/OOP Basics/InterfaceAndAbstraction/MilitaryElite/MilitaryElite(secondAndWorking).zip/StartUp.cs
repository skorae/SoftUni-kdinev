﻿using MilitaryElite.Soldiers;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MilitaryElite
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string command = Console.ReadLine();
            List<Private> privates = new List<Private>();

            while (command != "End")
            {
                string[] arr = command.Split();

                string type = arr[0];
                int id = int.Parse(arr[1]);
                string firstName = arr[2];
                string lastName = arr[3];
                string specialization = "";

                if (type == "Spy")
                {
                    Spy spy = new Spy(id, firstName, lastName, int.Parse(arr[4]));
                    Console.WriteLine(spy);
                }
                decimal salary = decimal.Parse(arr[4]);

                switch (type)
                {
                    case "Private":
                        Private @private = new Private(id, firstName, lastName, salary);
                        privates.Add(@private);
                        Console.WriteLine(@private);
                        break;
                    case "LieutenantGeneral":
                        LeutenantGeneral general = new LeutenantGeneral(id, firstName, lastName, salary);

                        if (arr.Length > 4)
                        {
                            for (int i = 5; i < arr.Length; i++)
                            {
                                general.Privates.Add(privates.FirstOrDefault(x => x.Id == int.Parse(arr[i])));
                            }
                        }
                        Console.WriteLine(general);
                        break;
                    case "Engineer":
                        specialization = arr[5];
                        if (!ValidSpecialization(specialization))
                        {
                            command = Console.ReadLine();
                            continue;
                        }
                        Engineere engineere = new Engineere(id, firstName, lastName, salary,specialization);

                        if (arr.Length > 5)
                        {
                            for (int i = 6; i < arr.Length; i+=2)
                            {
                                string skill = arr[i];
                                int time = int.Parse(arr[i + 1]);
                                engineere.Repairs.Add(skill, time);
                            }
                        }
                        Console.WriteLine(engineere);
                        break;
                    case "Commando":
                        specialization = arr[5];
                        if (!ValidSpecialization(specialization))
                        {
                            command = Console.ReadLine();
                            continue;
                        }
                        Commando commando = new Commando(id, firstName, lastName, salary, specialization);
                        if (arr.Length > 5)
                        {
                            for (int i = 6; i < arr.Length; i += 2)
                            {
                                string mission = arr[i];
                                string status = arr[i + 1];
                                if (!GetStatus(status))
                                {
                                    continue;
                                }
                                commando.Missions.Add(mission, status);
                            }
                        }
                        Console.WriteLine(commando);
                        break;
                }
                command = Console.ReadLine();
            }
        }

        private static bool GetStatus(string status)
        {
            if (status == "inProgress" || status == "Finished")
            {
                return true;
            }
            return false;
        }

        private static bool ValidSpecialization(string specialization)
        {
            if (specialization == "Marines" || specialization == "Airforces")
            {
                return true;
            }
            return false;
        }
    }
}
