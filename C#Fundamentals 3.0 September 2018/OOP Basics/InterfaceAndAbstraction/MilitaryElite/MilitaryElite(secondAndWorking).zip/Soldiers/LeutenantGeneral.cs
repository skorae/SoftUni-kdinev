﻿using MilitaryElite.Interface;
using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite.Soldiers
{
    public class LeutenantGeneral : ILieutenantGeneral
    {
        public LeutenantGeneral(int id, string firstName, string lastName, decimal salary)
        {
            this.Id = id;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Salary = salary;
            this.Privates = new List<Private>();
        }

        public List<Private> Privates { get; set; }
        public decimal Salary { get; set; }
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public override string ToString()
        {
            StringBuilder builder = new StringBuilder();

            builder.AppendLine($"Name: {this.FirstName} {this.LastName} Id: {this.Id} Salary: {this.Salary:f2}");
            builder.AppendLine("Privates:");
            if (this.Privates.Count != 0)
            {
                foreach (var m in this.Privates)
                {
                    builder.AppendLine($"  {m}");
                }
            }
            return builder.ToString().Trim();
        }
    }
}
