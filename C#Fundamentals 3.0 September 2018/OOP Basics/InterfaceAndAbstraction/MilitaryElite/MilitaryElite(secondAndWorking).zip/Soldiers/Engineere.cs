﻿using MilitaryElite.Interface;
using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite.Soldiers
{
    public class Engineere : IEngineer
    {
        public Engineere(int id, string firstName, string lastName, decimal salary,string specialization)
        {
            this.Id = id;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Salary = salary;
            this.Specialization = specialization;
            this.Repairs = new Dictionary<string, int>();
        }
        public Dictionary<string, int> Repairs { get; set; }

        public string Specialization { get; set; }

        public decimal Salary { get; set; }

        public int Id { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public override string ToString()
        {
            StringBuilder builder = new StringBuilder();

            builder.AppendLine($"Name: {this.FirstName} {this.LastName} Id: {this.Id} Salary: {this.Salary:f2}");
            builder.AppendLine($"Corps: {this.Specialization}");
            builder.AppendLine("Repairs:");
            if (this.Repairs.Count != 0)
            {
                foreach (var m in this.Repairs)
                {
                    builder.AppendLine($"  Part Name: {m.Key} Hours Worked: {m.Value}");
                }
            }
            return builder.ToString().Trim();
        }
    }
}
