﻿using MilitaryElite.Objects;
using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite.Interface
{
   public interface ILieutenantGeneral
    {
        List<Private> Privates { get; }
    }
}
