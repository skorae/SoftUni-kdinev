﻿using System;

namespace Ferrari
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Console.WriteLine(new Ferrari(Console.ReadLine()).ToString());
        }
    }
}
