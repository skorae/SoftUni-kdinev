﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MordorsCruelPlan.Foods
{
    public class Cram : Food
    {
        private const int happines = 2;

        public Cram()
            : base(happines)
        {
        }
    }
}
