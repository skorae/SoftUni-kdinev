﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MordorsCruelPlan.Foods
{
    public class Lembas : Food
    {
        private const int happines = 3;

        public Lembas()
            : base(happines)
        {
        }
    }
}
