﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MordorsCruelPlan.Foods
{
    public class Melon : Food
    {
        private const int happines = 1;

        public Melon()
            : base(happines)
        {
        }
    }
}
