﻿using System;
using WildFarm.Core;

namespace WildFarm
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
