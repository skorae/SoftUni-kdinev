﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Objects.Foods.Contracts
{
    public interface IFood
    {
        int Quantity { get; }
    }
}
