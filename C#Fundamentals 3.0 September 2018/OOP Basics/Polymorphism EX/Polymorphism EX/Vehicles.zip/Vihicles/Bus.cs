﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vihicles.Vihicles
{
    public class Bus : Vihicle
    {
        public Bus(double quantity, double consuption, double tank) 
            : base(quantity, consuption, tank)
        {
        }
    }
}
