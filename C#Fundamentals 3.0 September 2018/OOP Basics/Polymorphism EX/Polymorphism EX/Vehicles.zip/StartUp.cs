﻿using System;
using Vihicles.Core;

namespace Vihicles
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
