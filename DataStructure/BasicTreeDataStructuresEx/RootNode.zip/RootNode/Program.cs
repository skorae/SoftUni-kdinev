﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        TreeExtensions.ReadTree();

        Console.WriteLine($"Root node: {GetRootNode().Value}");
    }

    private static Tree<int> GetRootNode()
    {
        return TreeExtensions.Tree.Values.FirstOrDefault(x => x.Parent == null);
    }
}