﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

public class ReversedList<T> : IEnumerable<T>
{
    private List<T> arr;
    private const int InitialCapacity = 2;

    public ReversedList()
    {
        this.arr = new List<T>(InitialCapacity);
    }
    public void Add(T element)
    {
        this.arr.Insert(0, element);
    }

    public void RemoveAt(int index)
    {
        this.arr.RemoveAt(index);
    }

    public IEnumerator<T> GetEnumerator()
    {
        //for (int i = this.arr.Count - 1; i >= 0; i--)
        //{
        //    yield return this.arr[i];
        //}
        foreach (var item in this.arr)
        {
            yield return item;
        }
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
        return this.GetEnumerator();
    }
}
