﻿using System;

namespace ArrayBasedStack
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayStack<int> arr = new ArrayStack<int>();

            arr.Push(1);
            arr.Push(2);

            Console.WriteLine(arr.Pop());
            Console.WriteLine(arr.Pop());

            for (int i = 0; i < 20; i++)
            {
                arr.Push(i);
            }

            Console.WriteLine(string.Join(" ", arr.ToArray()));
        }
    }
}
